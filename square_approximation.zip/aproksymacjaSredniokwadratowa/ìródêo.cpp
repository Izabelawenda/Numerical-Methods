#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <graphics.h>

bool linapr(int n, double x[], double y[], double& a, double& b, double eps)
{
    double sx = 0, sy = 0, sxx = 0, sxy = 0, det;
    for (int k = 0; k < n; k++)
    {
        sx += x[k];
        sy += y[k];
        sxx += x[k] * x[k];
        sxy += x[k] * y[k];
    }
    if ((det = sxx * n - sx * sx) > -eps && det < eps)
        return false;
    a = (sxy * n - sx * sy) / det;
    b = (sxx * sy - sx * sxy) / det;
    return true;
}

using namespace std;

int n = 0;                          //punkty
double* x = NULL, * y = NULL;        // tablice wsp�rz�dnych punkt�w
double a, b;                        // wsp�czynniki prostej
double xRmin, xRmax, yRmin, yRmax;  // parametry uk�adu rzeczywistego
int xEmin, xEmax, yEmin, yEmax;     // parametry uk�adu ekranowego
double yPoc, yKon;                  // warto�ci ko�cowe prostej
double sx, sy;                      // czynniki skaluj�ce

void error(string err)
{
    if (x != NULL) delete[] x;
    if (y != NULL) delete[] y;
    cout << err << endl;
    getchar();
}

bool czytajdane()
{
    cout << "Nazwa pliku: ";
    string s;
    cin >> s;
    ifstream plik(s.c_str());
    if (!plik)
    {
        error("Nieudane otwarcie pliku.");
        return false;
    }
    if (!(plik >> n))
    {
        error("Nieudany odczyt liczby ca\x88kowitej.");
        return false;
    }
    if (n < 2)
    {
        error("Wymagane co najmniej dwa punkty.");
        return false;
    }
    x = new double[n];
    y = new double[n];
    for (int k = 0; k < n; k++)
        if (!(plik >> x[k] >> y[k]))
        {
            error("Nieudany odczyt liczby rzeczywistej.");
            return false;
        }
    plik.close();
    return true;
}

void min_max()
{
    xRmin = xRmax = x[0];
    yRmin = yRmax = y[0];
    for (int k = 1; k < n; k++)
    {
        if (x[k] < xRmin)
            xRmin = x[k];
        else if (x[k] > xRmax)
            xRmax = x[k];
        if (y[k] < yRmin)
            yRmin = y[k];
        else if (y[k] > yRmax)
            yRmax = y[k];
    }
}

void korekta()
{
    double d = 0.05 * (xRmax - xRmin);
    xRmin -= d;
    xRmax += d;
    if ((yPoc = a * xRmin + b) < yRmin)
        yRmin = yPoc;
    else if (yPoc > yRmax)
        yRmax = yPoc;
    if ((yKon = a * xRmax + b) < yRmin)
        yRmin = yKon;
    else if (yKon > yRmax)
        yRmax = yKon;
    if (yRmax - yRmin < linaprEPS)
    {
        if (yRmax > linaprEPS)
            d = yRmax;
        else if (yRmax < -linaprEPS)
            d = -yRmax;
        else
            d = linaprEPS;
        yRmax += d;
        yRmin -= d;
    }
}

int xE(double x)
{
    return int(sx * (x - xRmin)) + xEmin;
}

int yE(double y)
{
    return int(sy * (y - yRmin)) + yEmin;
}

void rysuj()
{
    xEmin = getmaxx() / 20;
    xEmax = getmaxx() - xEmin;
    yEmax = getmaxy() / 20;
    yEmin = getmaxy() - yEmax;
    sx = (xEmax - xEmin) / (xRmax - xRmin);
    sy = (yEmax - yEmin) / (yRmax - yRmin);
    line(xEmin, yE(yPoc), xEmax, yE(yKon));
    setcolor(LIGHTCYAN);
    for (int k = 0; k < n; k++)
    {
        int xp = xE(x[k]), yp = yE(y[k]);
        circle(xp, yp, 3);
        floodfill(xp, yp, LIGHTCYAN);
    }
}

int main()
{
    if (!czytajdane())
        return 1;
    if (!linapr(n, x, y, a, b))
    {
        error("Nieprawid\x88owe dane (uk\x88" "ad osobliwy).");
        return 2;
    }
    cout << "y = ax + b\n--------------\n";
    cout.setf(ios::fixed, ios::floatfield);
    cout << "a = " << setprecision(5) << a << endl;
    cout << "b = " << setprecision(5) << b << endl;
    min_max();
    korekta();
    initwindow(720, 480, "Aproksymacja �redniokwadratowa");
    rysuj();
    delete[] x;
    delete[] y;
    getch();
    closegraph();
    return 0;
}