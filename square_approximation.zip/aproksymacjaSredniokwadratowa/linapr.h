#pragma once

#ifndef H_LINAPR
#define H_LINAPR

const double linaprEPS = 0.5e-8;

bool linapr(int n, double x[], double y[], double& a, double& b, double eps = linaprEPS);

#endif 
