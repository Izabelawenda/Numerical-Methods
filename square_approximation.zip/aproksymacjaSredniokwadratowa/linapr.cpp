#include "linapr.h"

bool linapr(int n, double x[], double y[], double& a, double& b, double eps)
{
	double sx = 0, sy = 0, sxx = 0, sxy = 0, det;
	for (int k = 0; k < n; k++)
	{
		sx += x[k];
		sy += y[k];
		sxx += x[k] * x[k];
		sxy += x[k] * y[k];
	}
	if ((det = sxx * n - sx * sx) > -eps && det < eps)
		return false;
	a = (sxy * n - sx * sy) / det;
	b = (sxx * sy - sx * sxy) / det;
	return true;
}
