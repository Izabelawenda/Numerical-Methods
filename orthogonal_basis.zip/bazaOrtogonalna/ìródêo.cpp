#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

double norma(double* x, int length) {
    int i, length5;
    double a, sum = 0;

    length5 = length % 5;

    for (i = 0; i < length5; i++) {
        sum += x[i] * x[i];
    }
    for (; i < length; i += 5) {
        sum += x[i] * x[i] + x[i + 1] * x[i + 1] + x[i + 2] * x[i + 2]
            + x[i + 3] * x[i + 3] + x[i + 4] * x[i + 4];
    }

    return sqrt(sum);
}

void Scalardiv(double* x, double r, int length, double* y) {
    int i, length5;

    length5 = length % 5;

    for (i = 0; i < length5; i++) {
        y[i] = x[i] / r;
    }
    for (; i < length; i += 5) {
        y[i] = x[i] / r;
        y[i + 1] = x[i + 1] / r;
        y[i + 2] = x[i + 2] / r;
        y[i + 3] = x[i + 3] / r;
        y[i + 4] = x[i + 4] / r;
    }
}

void Scalarsub(double* x, double r, int length, double* y) {
    int i, length5;

    length5 = length % 5;

    for (i = 0; i < length5; i++) {
        y[i] -= r * x[i];
    }
    for (; i < length; i += 5) {
        y[i] -= r * x[i];
        y[i + 1] -= r * x[i + 1];
        y[i + 2] -= r * x[i + 2];
        y[i + 3] -= r * x[i + 3];
        y[i + 4] -= r * x[i + 4];
    }
}

double Productdot(double* x, double* y, int length) {
    int i, length5;
    double sum = 0;

    length5 = length % 5;

    for (i = 0; i < length5; i++) {
        sum += x[i] * y[i];
    }
    for (; i < length; i += 5) {
        sum += x[i] * y[i] + x[i + 1] * y[i + 1] + x[i + 2] * y[i + 2]
            + x[i + 3] * y[i + 3] + x[i + 4] * y[i + 4];
    }

    return sum;
}


void GramSchmidt(double** a, double** r, int m, int n, bool full) {
    int i, j;
    double anorm, tol = 10e-7;

    for (i = 0; i < n; i++) {
        r[i][i] = norma(a[i], m);            

        if (r[i][i] > tol) {
            Scalardiv(a[i], r[i][i], m, a[i]);
        }
        else if (i == 0) { 
            a[i][0] = 1;
            for (j = 1; j < m; j++) {
                a[i][j] = 0;
            }
        }
        else { 
            for (j = 0; j < m; j++) {
                a[i][j] = -a[0][i] * a[0][j];
            }
            a[i][i] += 1;

            for (j = 1; j < i; j++) {
                Scalarsub(a[j], a[j][i], m, a[i]);
            }

            anorm = norma(a[i], m);
            Scalardiv(a[i], anorm, m, a[i]);
        }

        for (j = i + 1; j < n; j++) {
            r[j][i] = Productdot(a[i], a[j], m); 
            Scalarsub(a[i], r[j][i], m, a[j]);   
        }
    }

    if (full) {
        for (; i < m; i++) {
            for (j = 0; j < m; j++) {
                a[i][j] = -a[0][i] * a[0][j];
            }
            a[i][i] += 1;

            for (j = 1; j < i; j++) {
                Scalarsub(a[j], a[j][i], m, a[i]);
            }

            anorm = norma(a[i], m);
            Scalardiv(a[i], anorm, m, a[i]);
        }
    }
}

int main() {

    int i, j, n, m, q_n, r_m;
    bool full;
    double x;

    cout << "Enter the dimension m: ";
    cin >> m;
    cout << "Enter the dimension n: ";
    cin >> n;

    if (m != n) {
       
        if (m < n) {
            printf("n <= m ");
            return 0;
        }
      
        cout << "Enter 0 4 QR factorization"<< endl;
        cout << " 1 4 a full QR factorization: ";
        cin >> full;
    }
    else { 

        full = 1;
    }

  
    if (full) { 
        q_n = m;
        r_m = m;
    }
    else { 
        q_n = n;
        r_m = n;
    }

    double** a = new double* [q_n];
    double** r = new double* [n];
    for (i = 0; i < n; i++) {
        a[i] = new double[m];
        r[i] = new double[r_m];
    }
    for (; i < q_n; i++) {
        a[i] = new double[m];
    }

    for (i = 0; i < n; i++) {
        for (j = i; j < m; j++) {
            a[i][j] = j - i + 1; 
        }
    }

    cout << "A = " << endl;
    for (i = 0; i < m; i++) {
        for (j = 0; j < n; j++) {
            printf("%9.6lg ", a[j][i]);
        }
        cout << endl;
    }
    cout << endl;

    GramSchmidt(a, r, m, n, full);


    cout << "Q = " << endl;
    for (i = 0; i < m; i++) {
        for (j = 0; j < q_n; j++) {
            if (a[j][i] >= 0) {
                cout << " ";
            }
            printf("%9.6lg ", a[j][i]);
        }
        cout << endl;
    }
    cout << endl;


    cout << "R = " << endl;
    for (i = 0; i < r_m; i++) {
        for (j = 0; j < n; j++) {
            printf("%9.6lg ", r[j][i]);
        }
        cout << endl;
    }
    cout << endl;

 
    printf("Numerical verification that {q_1, ..., q_%i} is an "
        "orthonormal set:\n", q_n);
    for (i = 0; i < q_n; i++) {
        for (j = i; j < q_n; j++) {
            x = Productdot(a[i], a[j], m);
            printf("q_%i * q_%i = %lg\n", i + 1, j + 1, x);
        }
    }

    for (i = 0; i < n; i++) {
        delete[] a[i];
        delete[] r[i];
    }
    for (; i < q_n; i++) {
        delete[] a[i];
    }
    delete[] a;
    delete[] r;

    return 0;    
}