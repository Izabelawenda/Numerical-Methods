#include <iostream>
#include<vector>
#include<cmath>
#include<fstream>
#include<utility>

using namespace std;

vector<double> wczytanie_wezlow(string filename) {

	ifstream plik(filename);
	double w;
	vector<double> v;
	while (plik >> w) v.push_back(w);

	return v;
} 

pair<vector<double>, vector<double>> wczytywanie_wartosci(string file) {

	ifstream filename;
	filename.open(file);
	//xi
	double w;
	//Ai
	double z;
	vector<double> a;
	vector<double> x;

	while (filename >> w) {
		filename >> z;
		x.push_back(w);
		a.push_back(z);
	}
	return make_pair(x, a);
}

double Horner(int n, vector<double> w, double p) {

	double y = w[n - 1];

	for (int i = n - 2; i >= 0; i--) {
		y = y * p + w[i];
	}
	return y;
}

double funkcja_1(double x) {

	static vector<double> p = wczytanie_wezlow("plik4.txt");
	return Horner(p.size(), p, x);
}

double funkcja_2(double x) {

	return x * x * pow(sin(x), 3);
}

double funkcja_3(double x) {

	return exp(x * x) * (x - 1);
}

double kwadratura_gaussa(double p1, double p2, int n, double (*f)(double)) {

	pair<vector<double>, vector<double>> dane;
	n = n - 1;
	if (n == 1) {
	cout << "Dla 2 wezlow: " << endl;
	 dane = wczytywanie_wartosci("plik.txt");
	}
	else if (n == 2) {
	cout << "Dla 3 wezlow: " << endl;
	 dane = wczytywanie_wartosci("plik1.txt");
	}
	else if (n == 3) {
	cout << "Dla 4 wezlow: " << endl;
	 dane = wczytywanie_wartosci("plik2.txt");
	}
	else if (n == 4) {
	cout << "Dla 5 wezlow: " << endl;
	 dane = wczytywanie_wartosci("plik3.txt");
	}
	
	double wynik = 0;
	vector<double> a;
	vector<double> x;
	x = dane.first;
	a = dane.second;

	for (int i = 0; i < x.size();i++) {
		x[i] = (p1) + (p2 - p1)*(x[i] + 1) / 2.0;
	}
	for (int i = 0; i <= n; i++) {
		wynik += a[i] * f(x[i]);
	}
	wynik *= (p2 - p1) / 2.0;

	return wynik;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

int main() {

	cout << "Wyniki dla pierwszej funkcji (sin)" << endl;
	for (int i = 2; i <= 5; i++){
		cout << kwadratura_gaussa(0, 4.5, i, funkcja_2) << endl;
	}

	cout << "Wyniki dla drugiej funkcji (exp)" << endl;
	for (int i = 2; i <= 5; i++) {
		cout << kwadratura_gaussa(-2, 2, i, funkcja_3) << endl;
	} 

	cout << "Wyniki dla podanego wielomianu" << endl;
	for (int i = 2; i <= 5; i++) {
		cout << kwadratura_gaussa(-2, 2, i, funkcja_1) << endl;
	}
}