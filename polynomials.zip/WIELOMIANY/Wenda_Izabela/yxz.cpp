#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>
using namespace std;

// 1.Obliczanie warto�ci wielomianu zadanego w postaci naturalnej dla dowolnej warto�ci x z wykorzystaniem schematu Hornera

int Horner(int wsp[], int st, int x)
{
	int outc = wsp[0];

	for (int i = 1; i <= st; i++)
	{
		outc = outc * x + wsp[i];
	}

	return outc;
}

// 2.Obliczanie warto�ci wielomianu zadanego w postaci Newtona dla dowolnej warto�ci x z wykorzystaniem uog�lnionego schematu Hornera

double Horner_Newton(double* w, double* x, unsigned int n, double xx)
{
	double y = w[n - 1];
	for (int i = n - 2; i >= 0; i--)
	{
		y = y * (xx - x[i]) + w[i];
	}
	return y;
}

// 3.Przekszta�cenie wielomianu z postaci Newtona na posta� naturaln�(przeliczenie wsp�czynnik�w)

double* Newton_Naturalna(double* b, double* X, unsigned int n)
{
	double* a = new double[n];
	a[n - 1] = b[n - 1];
	for (int i = n - 2; i >= 0; i--)
	{
		a[i] = b[i];
		for (int j = i; j < n - 1; j++)
		{
			a[j] -= X[i] * a[j + 1];
		}
	}
	return a;
}

// 4.Interpolacja Lagrange�a

double pom(unsigned int i, double* X, unsigned int n, double x)
{
	double pom = 1;
	for (int j = 0; j < n; j++)
	{
		if (j != i)
		{
			pom *= (x - X[j] / (X[i] - X[j]));
		}
	}
	return pom;
}

double Lagrange(double* X, double* Y, unsigned int n, double x)
{
	double y = 0;
	for (int i = 0; i < n; i++)
	{
		y += Y[i] * pom(i, X, n, x);
	}
	return y;
}

// 5.Posta� Newtona wielomianu Lagrange�a - wyznaczanie iloraz�w r�nicowych

double* Wspolczynniki(double* X, double* Y, unsigned int n)
{
	double** B = new double* [n];
	for (int i = 0; i < n; i++)
	{
		B[i] = new double[i + 1];
		B[i][0] = Y[i];
	}
	for (int i = 1; i < n; i++)
	{
		for (int j = 1; j <= i; j++)
		{
			B[i][j] = (B[i][j - 1] - B[i - 1][j - 1]) / (X[i] - X[i - j]);
		}
	}
	double* b = new double[n];
	for (int i = 0; i < n; i++)
	{
		b[i] = B[i][i];
	}
	for (int i = 0; i < n; i++)
	{
		delete[] B[i];
	}
	delete[] B;
	return b;
}

int main()
{
	//1 

	int* wsp;
	int stopien = 5, argument;
	wsp = new int[stopien + 1];

	for (int i = 0; i <= stopien; i++)
	{
		cout << "Wspolczynnik przy potedze " << stopien - i << ": ";
		cin >> wsp[i];
	}

	cout << "Argument x: ";
	cin >> argument;

	cout << "W( " << argument << " ) = " << Horner(wsp,stopien,argument) << endl;

	delete[] wsp;

	//2
	/*
	unsigned int n = 0; //liczba wezlow
	double xx;
	cout << "Wpisz x:" << endl;
	cin >> xx;
	fstream plik;

	plik.open("zad2.txt");
	plik >> n;
	cout << " nasze n: " << n << endl;
	double* x = new double[n];
	double* w = new double[n];
	string linia;
	do
	{
		for (int i = 0; i < n; i++)
		{
			plik >> w[i];
			plik.get();
			getline(plik, linia, ';');
			x[i] = atof(linia.c_str());
			cout << "w: " << w[i] << endl;
			cout << "x: " << x[i] << endl;
		}
	} while (linia != "");

	cout << "wynik:" << endl;
	cout << Horner_Newton(&w[n], &x[n], n, xx);
	*/
	//4
	/*
	unsigned int n = 0; //liczba wezlow
	double xx;
	cout << "Wpisz x:" << endl;
	cin >> xx;
	fstream plik;

	plik.open("zad4.txt");
	plik >> n;
	cout << " nasze n: " << n << endl;
	double* xg = new double[n];
	double* y = new double[n];
	string linia;
	do
	{
		for (int i = 0; i < n; i++)
		{
			plik >> xg[i];
			plik.get();
			getline(plik, linia, ';');
			y[i] = atof(linia.c_str());
			cout << "w: " << xg[i] << endl;
			cout << "x: " << y[i] << endl;
		}
	} while (linia != "");

	cout << "wynik:" << endl;
	cout << Lagrange(&xg[n], &y[n], n, xx);
	return 0;
	*/
	//5
	/*
	unsigned int n = 0; //liczba wezlow
	fstream plik;

	plik.open("zad5.txt");
	plik >> n;
	cout << " nasze n: " << n << endl;
	double* xw = new double[n];
	double* y = new double[n];
	string linia;
	do
	{
		for (int i = 0; i < n; i++)
		{
			plik >> xw[i];
			plik.get();
			getline(plik, linia, ';');
			y[i] = atof(linia.c_str());
			cout << "w: " << xw[i] << endl;
			cout << "x: " << y[i] << endl;
		}
	} while (linia != "");

	cout << "wynik:" << endl;
	cout << Wspolczynniki(&xw[n], &y[n], n);
	*/
	return 0;
}