#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
#include <string>
using namespace std;

//gauss elimination method implementation

const double eps = 1e-12;

bool Eliminacja_gaussa(int n, double** AB, double* X){

    int i, j, k;
    double m, s;

    for (i = 0; i < n - 1; i++){
        for (j = i + 1; j < n; j++){

            if (fabs(AB[i][i]) < eps) return false;
            m = -AB[j][i] / AB[i][i];
            for (k = i + 1; k <= n; k++)
                AB[j][k] += m * AB[i][k];
        }
    }

    for (i = n - 1; i >= 0; i--){

        s = AB[i][n];
        for (j = n - 1; j >= i + 1; j--)
            s -= AB[i][j] * X[j];
        if (fabs(AB[i][i]) < eps) return false;
        X[i] = s / AB[i][i];
    }
    return true;
}

int main()
{
    double** A, * b;
    int n = 4;
    int i, j;

    cout << setprecision(4) << fixed;

    // tworzymy macierze A i b

    A = new double* [n];
    b = new double[n];

    for (i = 0; i < n; i++) A[i] = new double[n + 1];

    // odczytujemy dane dla macierzy A

    for (i = 0; i < n; i++) {
        for (j = 0; j <= n; j++) {
            cin >> A[i][j];
        }
    }
        
    if (Eliminacja_gaussa(n, A, b))
    {
        for (i = 0; i < n; i++)
            cout << "x" << i + 1 << " = " << setw(9) << b[i]
            << endl;
    }
    else
        cout << "zero\n";


    for (i = 0; i < n; i++) delete[] A[i];
    delete[] A;
    delete[] b;

    return 0;
}