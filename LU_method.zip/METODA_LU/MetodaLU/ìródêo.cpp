#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

const double eps = 1e-12;


bool DoolitleAlg(int n, double** A){ //algorytm doolitle rozk�adu LU

    int i, j, k;
    double s;

    for (j = 0; j < n; j++){

        if (fabs(A[j][j]) < eps) return false;
        for (i = 0; i <= j; i++){
            s = 0;
            for (k = 0; k < i; k++) s += A[i][k] * A[k][j];
            A[i][j] -= s;
        }
        for (i = j + 1; i < n; i++){
            s = 0;
            for (k = 0; k < j; k++) s += A[i][k] * A[k][j];
            A[i][j] = (A[i][j] - s) / A[j][j];
        }
    }
    return true;
}

bool LU ( int n, double ** A )
{
  int i, j, k;

  for( k = 0; k < n - 1; k++ )
  {
    if( fabs ( A [ k ][ k ] ) < eps ) return false;

    for( i = k + 1; i < n; i++ )
      A [ i ][ k ] /= A [ k ][ k ];

    for( i = k + 1; i < n; i++ )
      for( j = k + 1; j < n; j++ )
        A [ i ][ j ] -= A [ i ][ k ] * A [ k ][ j ];
  }

  return true;
}


bool reverse ( int k, int n, double ** A, double ** X ) // macierz odwrotna A
{
  int    i, j;
  double s;

  for( i = 1; i < n; i++ ){

    s = 0;
    for( j = 0; j < i; j++ ) s += A [ i ][ j ] * X [ j ][ k ];
    X [ i ][ k ] -= s;
  }

  if( fabs ( A [ n-1 ][ n-1 ] ) < eps ) return false;

  X [ n-1 ][ k ] /= A [ n-1 ][ n-1 ];

  for( i = n - 2; i >= 0; i-- ){

    s = 0;
    for( j = i + 1; j < n; j++ ) s += A [ i ][ j ] * X [ j ][ k ];
    if( fabs ( A [ i ][ i ] ) < eps ) return false;
    X [ i ][ k ] = ( X [ i ][ k ] - s ) / A [ i ][ i ];
  }
  return true;
}

double** Free(double b[], int n, double** X, double** XX) {

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {

            XX[i][j] = X[i][j] * b[j];
        }
    }
    return XX;
}


int main()
{
    double** A, ** X, ** XX;
    int n, i, j;
    bool ok;

    cout << setprecision(3) << fixed;
    cout << "Wpisz rozmiar macierzy: " << endl;
    cin >> n;

    A = new double* [n];
    X = new double* [n];
    XX = new double* [n];

    for (i = 0; i < n; i++){

        A[i] = new double[n];
        X[i] = new double[n];
        XX[i] = new double[n];
    }
    cout << "Wnetrze macierzy: " << endl;
    for (i = 0; i < n; i++){
        for (j = 0; j < n; j++) cin >> A[i][j];
    }

    if (DoolitleAlg(n, A)) {
        for (i = 0; i < n; i++){
            for (j = 0; j < n; j++){
                cout << setw(8) << A[i][j] << " ";
            } 
            cout << endl;
        }
    }   
    else{
        cout << "DZIELNIK ZERO\n";
    }

    if (LU(n, A)){

        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++) X[i][j] = 0;
            X[i][i] = 1;
        }

        ok = true;
        for (i = 0; i < n; i++)
            if (!reverse(i, n, A, X))
            {
                ok = false;
                break;
            }
    }
    else ok = false;

    if (ok)
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
                cout << setw(10) << X[i][j] << " ";
            cout << endl;
        }
    }
    else cout << "DZIELNIK ZERO\n";


    cout << "Wpisz wektor wyrazow wolnych: " << endl;
    double B[3];
    for (i = 0; i < n; i++) {
        cin >> B[i];
    }

    Free(B, n, A, XX);

    cout << "Wektor X: " << endl;
    for (int i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            cout << setw(8) << XX[i][j] << " ";
        }
        cout << endl;
    }

    for (i = 0; i < n; i++)
    {
        delete[] A[i];
        delete[] X[i];
    }
    delete[] A;
    delete[] X;
    delete[] B;
    return 0;
}