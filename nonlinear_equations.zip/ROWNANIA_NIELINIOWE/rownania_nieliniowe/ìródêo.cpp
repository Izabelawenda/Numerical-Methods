#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
using namespace std;

const double EPS0 = 0.0000000001; // porownanie do zera
const double EPSX = 0.0000000001; // wyznaczenie pierwiatska

//nasze funkcje

double function_1(double x) {
	return (x * x * x) + (x * x) - (3 * x) - 3;
}

double function_2(double x) {
	return (x * x) - 2;
}

double function_3(double x) {
	return sin(x * x) - (x * x);
}
double function_4(double x) {
	return sin(x * x) - (x * x) + 0.5;
}

//obliczenie pochodnej danej funkcji

double derivative_1(double x) {
	return (3 * x * x) + (2 * x) - 3;
}

double derivative_2(double x) {
	return 2 * x;
}

double derivative_3_4(double x) {
	return (2 * x * (cos(x * x))) - (2 * x); //pochodna funkcji 3 i 4 jest taka sama
}

//Newton

void Newton_1(int i, double x1, double x0, double f0, double f1) {
	while (i && (fabs(x1 - x0) > EPSX) && (fabs(f0) > EPS0)) {

		f1 = derivative_1(x0);
		if (fabs(f1) < EPS0) {
			cout << "Wrong start point" << endl;
			i = 0;
			break;
		}
		x1 = x0;
		x0 = x0 - f0 / f1;
		f0 = function_1(x0);
		if (!(--i)) {
			cout << "Limit of iteration exceeded!";
		}
	}

	if (i) {
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Newton_2(int i, double x1, double x0, double f0, double f1) {
	while (i && (fabs(x1 - x0) > EPSX) && (fabs(f0) > EPS0)) {

		f1 = derivative_2(x0);
		if (fabs(f1) < EPS0) {
			cout << "Wrong start point" << endl;
			i = 0;
			break;
		}
		x1 = x0;
		x0 = x0 - f0 / f1;
		f0 = function_2(x0);
		if (!(--i)) {
			cout << "Limit of iteration exceeded!";
		}
	}

	if (i) {
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Newton_3(int i, double x1, double x0, double f0, double f1) {
	while (i && (fabs(x1 - x0) > EPSX) && (fabs(f0) > EPS0)) {

		f1 = derivative_3_4(x0);
		if (fabs(f1) < EPS0) {
			cout << "Wrong start point" << endl;
			i = 0;
			break;
		}
		x1 = x0;
		x0 = x0 - f0 / f1;
		f0 = function_3(x0);
		if (!(--i)) {
			cout << "Limit of iteration exceeded!";
		}
	}

	if (i) {
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Newton_4(int i, double x1, double x0, double f0, double f1) {
	while (i && (fabs(x1 - x0) > EPSX) && (fabs(f0) > EPS0)) {

		f1 = derivative_3_4(x0);
		if (fabs(f1) < EPS0) {
			cout << "Wrong start point" << endl;
			i = 0;
			break;
		}
		x1 = x0;
		x0 = x0 - f0 / f1;
		f0 = function_4(x0);
		if (!(--i)) {
			cout << "Limit of iteration exceeded!";
		}
	}

	if (i) {
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

//metoda siecznych

void Siecznych_1(int i, double x1, double x0, double x2, double f0, double f1, double f2) {
	while (i && (fabs(x1 - x2) > EPSX)) {

		if (fabs(f1 - f2) < EPS0)
		{
			cout << "Wrong start points\n";
			i = 0;
			break;
		}
		x0 = x1 - f1 * (x1 - x2) / (f1 - f2);
		f0 = function_1(x0);
		if (fabs(f0) < EPS0) break;
		x2 = x1; f2 = f1;
		x1 = x0; f1 = f0;
		if (!(--i)) {
			cout << "Limit of iteration exceeded!";
		}
	}

	if (i) {
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Siecznych_2(int i, double x1, double x0, double x2, double f0, double f1, double f2) {
	while (i && (fabs(x1 - x2) > EPSX)) {

		if (fabs(f1 - f2) < EPS0)
		{
			cout << "Wrong start points\n";
			i = 0;
			break;
		}
		x0 = x1 - f1 * (x1 - x2) / (f1 - f2);
		f0 = function_2(x0);
		if (fabs(f0) < EPS0) break;
		x2 = x1; f2 = f1;
		x1 = x0; f1 = f0;
		if (!(--i)) {
			cout << "Limit of iteration exceeded!";
		}
	}

	if (i) {
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Siecznych_3(int i, double x1, double x0, double x2, double f0, double f1, double f2) {
	while (i && (fabs(x1 - x2) > EPSX)) {

		if (fabs(f1 - f2) < EPS0)
		{
			cout << "Wrong start points\n";
			i = 0;
			break;
		}
		x0 = x1 - f1 * (x1 - x2) / (f1 - f2);
		f0 = function_3(x0);
		if (fabs(f0) < EPS0) break;
		x2 = x1; f2 = f1;
		x1 = x0; f1 = f0;
		if (!(--i)) {
			cout << "Limit of iteration exceeded!";
		}
	}

	if (i) {
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Siecznych_4(int i, double x1, double x0, double x2, double f0, double f1, double f2) {
	while (i && (fabs(x1 - x2) > EPSX)) {

		if (fabs(f1 - f2) < EPS0)
		{
			cout << "Wrong start points\n";
			i = 0;
			break;
		}
		x0 = x1 - f1 * (x1 - x2) / (f1 - f2);
		f0 = function_4(x0);
		if (fabs(f0) < EPS0) break;
		x2 = x1; f2 = f1;
		x1 = x0; f1 = f0;
		if (!(--i)) {
			cout << "Limit of iteration exceeded!";
		}
	}

	if (i) {
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

//falsi

void Falsi_1(double a, double b, double f0, double fa, double fb, double x1, double x0) {
	if (fa * fb > 0) cout << "the function does not meet the assumptions" << endl;
	else
	{
		while (fabs(x1 - x0) > EPSX)
		{
			x1 = x0;
			x0 = a - fa * (b - a) / (fb - fa);
			f0 = function_1(x0);
			if (fabs(f0) < EPS0) break;
			if (fa * f0 < 0)
			{
				b = x0; fb = f0;
			}
			else
			{
				a = x0; fa = f0;
			}
		}
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Falsi_2(double a, double b, double f0, double fa, double fb, double x1, double x0) {
	if (fa * fb > 0) cout << "the function does not meet the assumptions" << endl;
	else
	{
		while (fabs(x1 - x0) > EPSX)
		{
			x1 = x0;
			x0 = a - fa * (b - a) / (fb - fa);
			f0 = function_2(x0);
			if (fabs(f0) < EPS0) break;
			if (fa * f0 < 0)
			{
				b = x0; fb = f0;
			}
			else
			{
				a = x0; fa = f0;
			}
		}
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Falsi_3(double a, double b, double f0, double fa, double fb, double x1, double x0) {
	if (fa * fb > 0) cout << "the function does not meet the assumptions" << endl;
	else
	{
		while (fabs(x1 - x0) > EPSX)
		{
			x1 = x0;
			x0 = a - fa * (b - a) / (fb - fa);
			f0 = function_3(x0);
			if (fabs(f0) < EPS0) break;
			if (fa * f0 < 0)
			{
				b = x0; fb = f0;
			}
			else
			{
				a = x0; fa = f0;
			}
		}
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Falsi_4(double a, double b, double f0, double fa, double fb, double x1, double x0) {
	if (fa * fb > 0) cout << "the function does not meet the assumptions" << endl;
	else
	{
		while (fabs(x1 - x0) > EPSX)
		{
			x1 = x0;
			x0 = a - fa * (b - a) / (fb - fa);
			f0 = function_4(x0);
			if (fabs(f0) < EPS0) break;
			if (fa * f0 < 0)
			{
				b = x0; fb = f0;
			}
			else
			{
				a = x0; fa = f0;
			}
		}
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

//metoda polowienia

void Bisekcja_1(double a, double b, double x0, double fa, double fb, double f0) {
	if (fa * fb > 0) {
		cout << "the function does not meet the assumptions" << endl;
	}
	else
	{
		while (fabs(a - b) > EPSX)
		{
			x0 = (a + b) / 2; f0 = function_1(x0);
			if (fabs(f0) < EPS0) break;
			if (fa * f0 < 0) b = x0;
			else
			{
				a = x0; fa = f0;
			}
		}
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Bisekcja_2(double a, double b, double x0, double fa, double fb, double f0) {
	if (fa * fb > 0) {
		cout << "the function does not meet the assumptions" << endl;
	}
	else
	{
		while (fabs(a - b) > EPSX)
		{
			x0 = (a + b) / 2; f0 = function_2(x0);
			if (fabs(f0) < EPS0) break;
			if (fa * f0 < 0) b = x0;
			else
			{
				a = x0; fa = f0;
			}
		}
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Bisekcja_3(double a, double b, double x0, double fa, double fb, double f0) {
	if (fa * fb > 0) {
		cout << "the function does not meet the assumptions" << endl;
	}
	else
	{
		while (fabs(a - b) > EPSX)
		{
			x0 = (a + b) / 2; f0 = function_3(x0);
			if (fabs(f0) < EPS0) break;
			if (fa * f0 < 0) b = x0;
			else
			{
				a = x0; fa = f0;
			}
		}
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

void Bisekcja_4(double a, double b, double x0, double fa, double fb, double f0) {
	if (fa * fb > 0) {
		cout << "the function does not meet the assumptions" << endl;
	}
	else
	{
		while (fabs(a - b) > EPSX)
		{
			x0 = (a + b) / 2; f0 = function_4(x0);
			if (fabs(f0) < EPS0) break;
			if (fa * f0 < 0) b = x0;
			else
			{
				a = x0; fa = f0;
			}
		}
		cout << "x0 = " << setw(15) << x0 << endl;
	}
}

int main() {

	double a, b, x0, x1, x2, f0, f1 = 0, f2, fa, fb;
	int i = 64;

	int choice;
	cout << "Choose a function:" << endl;
	cout << "1. x^3 + x^2 - 3x - 3 = 0" << endl;
	cout << "2. x^2 - 2 = 0" << endl;
	cout << "3. sin(x^2) - x^2 = 0" << endl;
	cout << "4. sin(x^2) - x^2 + 0,5 = 0" << endl;
	cin >> choice;

	switch (choice) {
		case 1:
			//newton

			cout << "Set a start point x0: ";
			cin >> x0;
			cout << "" << endl;
			x1 = x0 - 1;
			f0 = function_1(x0);
			cout << "NEWTON" << endl;
			Newton_1(i, x1, x0, f0, f1);

			//sieczne

			cout << "Set two start points x1, x2:";
			cin >> x1; cin >> x2;
			f1 = function_1(x1); 
			f2 = function_1(x2);
			cout << "METODA SIECZNYCH" << endl;
			Siecznych_1(i, x1, x0, x2, f0, f1, f2);

			//falsi

			cout << "Set search range <a,b>:";
			cin >> a; cin >> b;
			fa = function_1(a); 
			fb = function_1(b); 
			x1 = a; x0 = b;
			cout << "REGULA FALSI" << endl;
			Falsi_1(a, b, f0, fa, fb, x1, x0);

			//bisekcja

			cout << "Set search range <a,b>:";
			cin >> a; cin >> b;
			fa = function_1(a); fb = function_1(b);
			cout << "METODA POLOWIENIA" << endl;
			Bisekcja_1(a, b, x0, fa, fb, f0);

			break;
		case 2:
			//newton

			cout << "Set a start point x0: ";
			cin >> x0;
			cout << "" << endl;
			x1 = x0 - 1;
			f0 = function_2(x0);
			cout << "NEWTON" << endl;
			Newton_2(i, x1, x0, f0, f1);

			//sieczne

			cout << "Set two start points x1, x2:";
			cin >> x1; cin >> x2;
			f1 = function_2(x1);
			f2 = function_2(x2);
			cout << "METODA SIECZNYCH" << endl;
			Siecznych_2(i, x1, x0, x2, f0, f1, f2);

			//falsi

			cout << "Set search range <a,b>:";
			cin >> a; cin >> b;
			fa = function_2(a);
			fb = function_2(b);
			x1 = a; x0 = b;
			cout << "REGULA FALSI" << endl;
			Falsi_2(a, b, f0, fa, fb, x1, x0);

			//bisekcja

			cout << "Set search range <a,b>:";
			cin >> a; cin >> b;
			fa = function_2(a); fb = function_2(b);
			cout << "METODA POLOWIENIA" << endl;
			Bisekcja_2(a, b, x0, fa, fb, f0);

			break;
		case 3:
			//newton

			cout << "Set a start point x0: ";
			cin >> x0;
			cout << "" << endl;
			x1 = x0 - 1;
			f0 = function_3(x0);
			cout << "NEWTON" << endl;
			Newton_3(i, x1, x0, f0, f1);

			//sieczne

			cout << "Set two start points x1, x2:";
			cin >> x1; cin >> x2;
			f1 = function_3(x1);
			f2 = function_3(x2);
			cout << "METODA SIECZNYCH" << endl;
			Siecznych_3(i, x1, x0, x2, f0, f1, f2);

			//falsi

			cout << "Set search range <a,b>:";
			cin >> a; cin >> b;
			fa = function_3(a);
			fb = function_3(b);
			x1 = a; x0 = b;
			cout << "REGULA FALSI" << endl;
			Falsi_3(a, b, f0, fa, fb, x1, x0);

			//bisekcja

			cout << "Set search range <a,b>:";
			cin >> a; cin >> b;
			fa = function_3(a); fb = function_3(b);
			cout << "METODA POLOWIENIA" << endl;
			Bisekcja_3(a, b, x0, fa, fb, f0);

			break;
		case 4:
			//newton

			cout << "Set a start point x0: ";
			cin >> x0;
			cout << "" << endl;
			x1 = x0 - 1;
			f0 = function_4(x0);
			cout << "NEWTON" << endl;
			Newton_4(i, x1, x0, f0, f1);

			//sieczne

			cout << "Set two start points x1, x2:";
			cin >> x1; cin >> x2;
			f1 = function_4(x1);
			f2 = function_4(x2);
			cout << "METODA SIECZNYCH" << endl;
			Siecznych_4(i, x1, x0, x2, f0, f1, f2);

			//falsi

			cout << "Set search range <a,b>:";
			cin >> a; cin >> b;
			fa = function_4(a);
			fb = function_4(b);
			x1 = a; x0 = b;
			cout << "REGULA FALSI" << endl;
			Falsi_4(a, b, f0, fa, fb, x1, x0);

			//bisekcja

			cout << "Set search range <a,b>:";
			cin >> a; cin >> b;
			fa = function_4(a); fb = function_4(b);
			cout << "METODA POLOWIENIA" << endl;
			Bisekcja_4(a, b, x0, fa, fb, f0);

			break;
	}


	return 0;
}