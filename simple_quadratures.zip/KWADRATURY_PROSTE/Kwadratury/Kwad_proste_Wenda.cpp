﻿#include <iostream>
#include <iomanip>
#include <stdio.h>
using namespace std;


double dzialanie_1(double x) {

	return x * x * pow(sin(x), 3);
}

double dzialanie_2(double x) {

	return exp(x * x) * (x - 1);
}

double metoda_trapezow(double a, double b) {

	double wysokosc = b - a;
	double pod_a = dzialanie_1(a);
	double pod_b = dzialanie_1(a + wysokosc);
	double suma_pol = pod_a + pod_b;
	return suma_pol * 0.5 * wysokosc;
}

double metoda_trapezow_complex(double a, double b, int n, double(*fun)(double)) {

	double wysokosc = b - a / (double)n;
	double suma_pol = 0.0;
	double pod_a = fun(a);
	double pod_b;

	for (int i = 1; i <= n; i++)
	{
		pod_b = fun(a + wysokosc * i);
		suma_pol += (pod_a + pod_b);
		pod_a = pod_b;
	}
	return suma_pol * 0.5 * wysokosc;
}

double metoda_simpsona(double a, double b, int n) {

	double wys = (b - a) / n;
	double sum = 0;

	for (int i = 0; i < n; i++) {
		double A = a + (i * wys);
		double B = a + ((i + 1) * wys);
		sum += (dzialanie_1(A) + (4 * dzialanie_1((A + B) / 2)) + dzialanie_1(B));
	}
	sum = sum * (wys / 6);
	return sum;
}

void zadanie_1() {

	double a, b, n;
	cout << "Nasza funkcja: x^2 + x + 2" << endl;
	cout << "Ustal przedzial [a, b]" << endl;
	cout << "a = ";
	cin >> a;
	cout << "b = ";
	cin >> b;

	if (!(a < b)) {
		cout << "Przedzial musi byc od mniejszej do wiekszej";
	}
	else {
		cout << "Powierzchnia:  " << fixed << setprecision(2) << metoda_trapezow(a, b) << endl;
	}
}

void zadanie_2() {

	double a, b, n;
	cout << "Nasza funkcja: x^2 * sin^3(x)" << endl;
	cout << "Ustal przedział [a, b]" << endl;
	cout << "a = "; 
	cin >> a;
	cout << "b = ";
	cin >> b;
	cout << "Wprowadz ilosc trapezow: ";
	cin >> n;

	if (!(a < b)) {
		cout << "Przedzial musi byc od mniejszej do wiekszej";
	}
	else {
		cout << "Powierzchnia:  " << fixed << setprecision(2) << metoda_trapezow_complex(a, b, n, dzialanie_1) << endl;
	}
}

/*
void zadanie_3() {
	
}
*/

void zadanie_4() {

	double a = 0;
	double b = 4.5;
	cout << "Nasza funkcja: x^2 * sin^3(x)" << endl;
	cout << "Powierzchnia:  " << fixed << setprecision(2) << metoda_trapezow_complex(a, b, 1, dzialanie_1) << endl;
}

void zadanie_5() {

	double a = -2;
	double b = 2;
	cout << "Nasza funkcja: exp(x^2)(x-1)" << endl;
	cout << "Powierzchnia:  " << fixed << setprecision(2) << metoda_trapezow_complex(a, b, 1, dzialanie_2) << endl;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main()
{
	cout << "Zadanie 1" << endl;
	zadanie_1();
	cout << "Zadanie 2" << endl;
	zadanie_2();
	/*
	cout << "Zadanie 3" << endl;
	zadanie_3();
	*/
	cout << "Zadanie 4" << endl;
	zadanie_4();
	cout << "Zadanie 5" << endl;
	zadanie_5();

	getchar(); getchar();
	return 0;
}